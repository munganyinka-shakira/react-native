export default {
    GRAY: '#b0b0b0',
    WHITE: '#fff',
    BLACK: '#000',
    DANGER: '#b03747',
    PRIMARY: '#f0a122',
    LIGHT: '#f0f0f0',
    DODGERBLUE: 'dodgerblue',
    GREEN: '#3dba63',
}