const mongodbOptions = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    autoIndex: true,
  };
  
  module.exports = { mongodbOptions };
  